import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;


class clima extends StatefulWidget {
  @override
  _ClimaState createState() => _ClimaState();
}

class _ClimaState extends State<clima> {
   TextEditingController _ciudadController = TextEditingController();
   String apiKey = 'e4615a16ba8988077915a988f6493bdb'; 
   double temperatura = 0.00;
   double humedad = 0;
   String descripcion= '';
   bool datosDisponibles = false;
   bool errorM = false;
   
@override
  Widget build(BuildContext context) {
     
     
    return Scaffold(
      appBar: AppBar(
        title: Text('Estación Meteorologica'),
      ),
     body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
             
              TextField(
                controller: _ciudadController,
                decoration: InputDecoration(
                  labelText: 'Ciudad',
                ),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: () async  {
                  final ciudad = _ciudadController.text;
                  await obtenerDatosDelClima(ciudad);
                  setState(() {
                    
                  });
                              
                },
                child: Text('Consultar Clima'),
              ),
              Visibility(
                visible: datosDisponibles,
                child: Column(
                  children: [
                    Text(
                      'Nombre: $descripcion',
                      style: TextStyle(fontSize: 18),
                    ),
                    Text(
                      'Temperatura: ${temperatura.toString()}°C',
                      style: TextStyle(fontSize: 18),
                    ),
                    Text(
                      'Humedad: ${humedad.toString()}%',
                      style: TextStyle(fontSize: 18),
                    ),
                    
                  ],
                ),
              ),
              Visibility(
                visible: errorM,
                child: Column(
                  children: [
                    Text(
                      'Ha ocurrido un error al realizar la consulta',
                      style: TextStyle(fontSize: 18),
                    ),
                  ],
                ),
              ),              
            ],
          ),
        ),
      ),
      
    );
  }

Future<void> obtenerDatosDelClima(String ciudad) async {
  final apiUrl = 'https://api.openweathermap.org/data/2.5/weather?q=$ciudad&appid=$apiKey';
  print(apiUrl);

  final response = await http.get(Uri.parse(apiUrl));

  if (response.statusCode == 200) {
    final data = jsonDecode(response.body);
     temperatura = data['main']['temp'];
     humedad = data['main']['humidity'];
     print(temperatura);
     temperatura = (temperatura - 273.15);
     print(temperatura);
     descripcion = data['name'];
     datosDisponibles = true;
      errorM = false;
  } else {
    print('Error al obtener datos del clima');
    datosDisponibles = false;
    errorM = true;
  }
}
}