package com.example.clima_mgu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
