fun main() {
    val numeros = mutableListOf<Double>()

    while (true) {
        println("Selecciona una opción:")
        println("1. Agregar un número a la lista")
        println("2. Calcular la suma de los números en la lista")
        println("3. Calcular el promedio de los números en la lista")
        println("4. Encontrar los números pares en la lista")
        println("5. Elevar al cuadrado todos los números en la lista")
        println("6. Salir del programa")

        when (readLine()?.toIntOrNull()) {
            1 -> {
                println("Ingresa un número:")
                val numero = readLine()?.toDoubleOrNull()
                if (numero != null) {
                    numeros.add(numero)
                    println("$numero fue agregado a la lista.")
                } else {
                    println("Entrada no válida. Ingresa un número válido.")
                }
            }
            2 -> {
                val suma = numeros.sum()
                println("La suma de los números en la lista es: $suma")
            }
            3 -> {
                val promedio = numeros.average()
                println("El promedio de los números en la lista es: $promedio")
            }
            4 -> {
                val numerosPares = numeros.filter { it % 2 == 0.0 }
                if (numerosPares.isNotEmpty()) {
                    println("Números pares en la lista:")
                    println(numerosPares.joinToString(", "))
                } else {
                    println("No hay números pares en la lista.")
                }
            }
            5 -> {
                val numerosCuadrados = numeros.map { it * it }
                println("Lista de números elevados al cuadrado:")
                println(numerosCuadrados.joinToString(", "))
            }
            6 -> {
                println("¡Hasta luego!")
                return
            }
            else -> {
                println("Opción no válida. Por favor, selecciona una opción válida.")
            }
        }
    }
}