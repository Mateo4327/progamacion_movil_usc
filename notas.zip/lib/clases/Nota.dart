class Nota {
  final String nombre;
  final String informacion;
  final DateTime fechaCreacion;

  Nota({required this.nombre, required this.informacion, DateTime? fechaCreacion})
      : fechaCreacion = fechaCreacion ?? DateTime.now();
}