import 'package:flutter/material.dart';
import 'package:flutter_application_1/vistasSecundarias/nuevaNota.dart';
import '../clases/Nota.dart';
import '../controlador/listaNotas.dart';

class Principal extends StatefulWidget {
  @override
  _PrincipalState createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> { 
  // Creamos una lista para almacenar las notas
  List<Nota> listaNotas = [];

 
  @override
  Widget build(BuildContext context) {
     
     
    return Scaffold(
      appBar: AppBar(
        title: Text('Las Notas de Mateo'),
      ),
      body: ListaNotasWidget(
        notas: listaNotas,
        eliminarNota: (Nota nota) {
          eliminarNotaFinal(nota);
        },
      ),
       floatingActionButton: FloatingActionButton(
          onPressed: () async {
           final notaCreada = await  Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => nuevaNota()),
            );

            if (notaCreada != null ) {
              setState(() {
              listaNotas.add(notaCreada);
            });
            }
          },
          child: Icon(Icons.add),
        ),
    );
  }

   void eliminarNotaFinal(Nota nota) {
    // Implementa la lógica para eliminar la nota aquí
    listaNotas.remove(nota);
    // Muestra el SnackBar de confirmación
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Se ha eliminado la nota con exito'),
        action: SnackBarAction(
          label: 'Deshacer',
          onPressed: () {
            setState(() {
              listaNotas.add(nota);
            });
          },
        ),
      ),
    );
  }
}