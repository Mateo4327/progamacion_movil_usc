import 'package:flutter/material.dart';
import '../clases/Nota.dart';

class nuevaNota extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    TextEditingController _nombreController = TextEditingController();
    TextEditingController _infomacionController = TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text('Crear Nota'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
                    child: Column(
                      children: [
                        SizedBox(height: 16),
                        TextFormField(
                          decoration: InputDecoration(labelText: 'Nombre'),
                          controller: _nombreController,
                        ),
                        SizedBox(height: 16),
                        TextFormField(
                          decoration: InputDecoration(labelText: 'Informacion'),
                          controller: _infomacionController,
                        ),
                        ElevatedButton(
                          onPressed: () {
                            var nota = Nota(nombre: _nombreController.text, informacion: _infomacionController.text);
                            // Devuelvo la nota creada a la vista principal
                            Navigator.pop(context, nota); 
                          },
                          child: Text('Almacenar Nota'),
                        ),
                      ],
                    ),
                  ),

      ),
    );
  }
}
