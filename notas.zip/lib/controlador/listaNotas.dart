import 'package:flutter/material.dart';
import '../clases/Nota.dart';

class ListaNotasWidget extends StatelessWidget {
  final List<Nota> notas;
  final Function(Nota) eliminarNota; 

  ListaNotasWidget({required this.notas, required this.eliminarNota});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: notas.length,
      itemBuilder: (context, index) {
        final nota = notas[index];
        return Dismissible(
          key: UniqueKey(),
          onDismissed: (direction) {
            eliminarNota(nota);
          },
          background: Container(
            color: Colors.blue,
            alignment: Alignment.centerRight,
            child: Icon(Icons.delete, color: Colors.white),
          ),
          child: ListTile(
            title: Text(nota.nombre),
            subtitle: Text(nota.informacion),
          ),
        );
      },
    );
  }
}
